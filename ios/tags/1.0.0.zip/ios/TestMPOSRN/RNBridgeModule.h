//
//  RNBridgeModule.h
//  TestAndroidToRN
//
//  Created by chengkai on 2018/6/22.
//  Copyright © 2018年 chengkai. All rights reserved.
//

#ifndef RNBridgeModule_h
#define RNBridgeModule_h

#import <React/RCTBridgeModule.h>
#import <React/RCTLog.h>

@interface RNBridgeModule : NSObject <RCTBridgeModule>
@end

#endif /* RNBridgeModule_h */
